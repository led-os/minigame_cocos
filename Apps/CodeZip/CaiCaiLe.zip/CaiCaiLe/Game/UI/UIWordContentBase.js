var UIView = require("UIView");
var UIWordContentBase = cc.Class({
    extends: UIView,// cc.ItemInfo, 
    properties: {

    },

    onLoad: function () {

    },

    LayOut() {

    },


    UpdateGuankaLevel(level) {
    },
    OnTips() {
    },

    OnAddWord(word) {
    },
    OnReset() {
    },


    CheckAllFill() {

    },
    CheckAllAnswerFinish() {

    },
    UpdateWord() {
    },

});

