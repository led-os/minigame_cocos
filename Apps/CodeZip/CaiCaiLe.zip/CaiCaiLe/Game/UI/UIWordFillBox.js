var UIWordContentBase = require("UIWordContentBase");
var UIWordFillBox = cc.Class({
    extends: UIWordContentBase,// cc.ItemInfo, 
    properties: {
      
    },

    onLoad: function () {

    }, 

    LayOut() {
        
    },

});

