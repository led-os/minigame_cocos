var UIView = require("UIView");
var UIWordItem = cc.Class({
    extends: UIView,// cc.ItemInfo, 
    properties: {
     
    },

    onLoad: function () {

    }, 

    LayOut() {
        
    },

});

