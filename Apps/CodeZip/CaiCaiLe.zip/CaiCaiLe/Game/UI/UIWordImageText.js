var UIView = require("UIView");
var UIWordImageText = cc.Class({
    extends: UIView,// cc.ItemInfo, 
    properties: {
     
    },

    onLoad: function () {

    }, 

    LayOut() {
        
    },

});

