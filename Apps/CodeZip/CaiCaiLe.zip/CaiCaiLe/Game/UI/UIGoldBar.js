var UIView = require("UIView");
var UIGoldBar = cc.Class({
    extends: UIView,// cc.ItemInfo, 
    properties: {
        imageBg: cc.UIImage,
        imageIcon: cc.UIImage,
        textGold: cc.UIText,
    },

    onLoad: function () {
        this._super();
    },

    LayOut() {
        this._super();
    },

});

