var UIView = require("UIView");
var UIGameFail = cc.Class({
    extends: UIView,// cc.ItemInfo, 
    properties: {
     
    },

    onLoad: function () {

    }, 

    LayOut() {
        
    },

});

