var UIGameWinBase = require("UIGameWinBase");
var UIGameWinIdiom = cc.Class({
    extends: UIGameWinBase,// cc.ItemInfo, 
    properties: {
     
    },

    onLoad: function () {

    }, 

    LayOut() {
        
    },

});

