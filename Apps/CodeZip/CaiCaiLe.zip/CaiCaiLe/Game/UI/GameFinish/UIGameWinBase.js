var UIView = require("UIView");
var UIGameWinBase = cc.Class({
    extends: cc.UIViewPop,// cc.ItemInfo, 
    properties: {
     
    },

    onLoad: function () {

    }, 

    LayOut() {
        
    },

});

