var UIView = require("UIView");
var UIIdiomDetail = cc.Class({
    extends: UIView,// cc.ItemInfo, 
    properties: {
     
    },

    onLoad: function () {

    }, 

    LayOut() {
        
    },

});

