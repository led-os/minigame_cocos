var UIView = require("UIView");
var UIGameItem = cc.Class({
    extends: UIView,// cc.ItemInfo, 
    properties: {
        imageBoard: cc.Sprite,
        imageItem: cc.Sprite,
    },

    onLoad: function () {


    },


});

